package com.example.quizapplication;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Builder
public class Question {
    @Setter @Getter private int answerId;
    @Setter @Getter private boolean answerTrue;
}
