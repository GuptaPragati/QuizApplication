package com.example.quizapplication;

import android.content.DialogInterface;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button trueButton;
    private Button falseButton;
    ImageButton imageButton;
    private TextView textView;
    private int score;
    private int currentQuestionIndex=0;
    private ProgressBar progressBar;
    Question[] questionBank=new Question[]
            {
                    new Question(R.string.Ques1,true),
                    new Question(R.string.Ques2,false),
                    new Question(R.string.Ques3,true),
                    new Question(R.string.Ques4,false),
                    new Question(R.string.Ques5,true),
                    new Question(R.string.Ques6,true),
                    new Question(R.string.Ques7,true),
                    new Question(R.string.Ques8,false),
            };
    final int USER_PROGRESS=(int)Math.ceil(100/questionBank.length);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        falseButton=findViewById(R.id.button);
        trueButton=findViewById(R.id.button2);
        textView=findViewById(R.id.questions);
        imageButton=findViewById(R.id.imageButton);
        progressBar=findViewById(R.id.progressBar);
        trueButton.setOnClickListener(this);
        falseButton.setOnClickListener(this);
        imageButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button:
                checkAnswer(false);
                break;
            case R.id.button2:
                checkAnswer(true);
                break;
            case R.id.imageButton:
                currentQuestionIndex=(currentQuestionIndex+1) % questionBank.length;
                updateQuestion();
        }
    }

    private void updateQuestion() {
        textView.setText(questionBank[currentQuestionIndex].getAnswerId());
        progressBar.incrementProgressBy(USER_PROGRESS);
        if (currentQuestionIndex==0)
        {
            AlertDialog.Builder alert=new AlertDialog.Builder(this);
            alert.setTitle("Quiz has been finished");
            alert.setMessage("Your Score is:"+score);
            alert.setPositiveButton("Finish quiz", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            alert.show();
        }
    }
    private void checkAnswer(boolean userAnswer)
    {
        boolean correctAnswer=questionBank[currentQuestionIndex].isAnswerTrue();
        int result;
        if (userAnswer==correctAnswer)
        {result=R.string.Correct_Ques;
        score=score+1;
        }
        else
        {result=R.string.Wrong_Ques;}
        Toast.makeText(MainActivity.this,result,Toast.LENGTH_LONG).show();
    }
}
